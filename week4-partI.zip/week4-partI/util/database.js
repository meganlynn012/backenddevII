const mongodb = require('mongodb');
const MongoClient = mongodb.MongoClient;

let _db;

const mongoConnect = callback => {
        //this function connects to the database. I place the page I want to go to where 'shop' is. 
    //If nothing exists in this database, Mongo will start creating it.
  MongoClient.connect(
    'mongodb+srv://megshaw:H011ykat@cluster0.ikusu.mongodb.net/shop?retryWrites=true&w=majority'
  )
    .then(client => {
      console.log('Connected!');
      _db = client.db(); //this calls the getDb function which will return access to the database everytime. This makes it so I don't have to import the function everytime I want to access the db.
      callback();
    })
    .catch(err => {
      console.log(err);
      throw err;
    });
};

const getDb = () => {
  if (_db) {
    return _db; //returns access to database
  }
  throw 'No database found!';
};

exports.mongoConnect = mongoConnect;
exports.getDb = getDb;
